using System;
using Reqnroll;

namespace Template.Hooks
{
    [Binding]
    public class Hooks
    {
        
    }
}